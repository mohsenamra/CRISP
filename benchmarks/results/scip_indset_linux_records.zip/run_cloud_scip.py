# Re-runs the SCIP experiment for independent set on one Linux machine (Windows SCIP build crashed on 22/80 instances).
import numpy as np, pickle, os, sys, time
from multiprocessing import Pool
from bench_lib import GENERATORS, solve, features
from extra_work import scip_work, LX
PR = pickle.load(open('/root/rec/preds/indset/preds.pkl', 'rb'))['preds'][:80]
os.makedirs('data/indset', exist_ok=True); os.makedirs('eval_x/scip/indset', exist_ok=True)
def job(item):
    n, p, tp = item; k = int(n[:4]); f = os.path.join('data/indset', n)
    if not os.path.exists(f):
        rng = np.random.default_rng(100_000 * 4 + k); P = GENERATORS['indset'](rng); F, tlp, zlp = features(P)
        z, x, t, _, st = solve(P, tlim=1200)
        pickle.dump(dict(P=P, F=F, t_lp=tlp, zlp=zlp, z=z, x=None if x is None else np.round(x), t_full=t, status=st), open(f, 'wb'))
    scip_work((f, os.path.join('eval_x/scip/indset', n), p, tp, LX))
    return n
if __name__ == '__main__':
    t0 = time.time()
    with Pool(2) as pool:
        for i, n in enumerate(pool.imap_unordered(job, PR)):
            print(f'{i+1}/80 {n} {(time.time()-t0)/60:.1f} min', flush=True)
    print('DONE', flush=True)
